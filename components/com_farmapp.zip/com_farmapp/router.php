<?php
/**
 * Joomla! 1.5 component Ideal Component
 *
 * @version $Id: router.php 2011-05-20 00:03:27 svn $
 * @author 
 * @author 
 * @package Joomla
 * @subpackage Ideal Component
 * @license GNU/GPL
 *
 * 
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/*
 * Function to convert a system URL to a SEF URL
 */
function IdealBuildRoute(&$query) {

}
/*
 * Function to convert a SEF URL back to a system URL
 */
function IdealParseRoute($segments) {

}
?>