<?php
/**
 * Joomla! 1.5 component ideal Component
 *
 * @version $Id: testcomponent.php 2011-05-20 00:03:27 svn $
 * @author 
 * @package Joomla
 * @subpackage ideal Component
 * @license GNU/GPL
 *
 * 
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

/**
 * ideal Component Component ideal Component Model
 *
 * @author      notwebdesign
 * @package		Joomla
 * @subpackage	ideal Component
 * @since 1.5
 */
class IdealModelIdeal extends JModel {
    /**
	 * Constructor
	 */
	function __construct() {
		parent::__construct();
    }
}
?>