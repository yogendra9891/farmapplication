<?php
/**
 * Joomla! 1.5 component ideal Component
 *
 * @version $Id: controller.php 2011-05-20 00:03:27 svn $
 * @author 
 * @package Joomla
 * @subpackage ideal Component
 * @license GNU/GPL
 *
 * 
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * ideal Component Component Controller
 */
class IdealController extends JController {
	function display() {
        // Make sure we have a default view
        if( !JRequest::getVar( 'view' )) {
		    JRequest::setVar('view', 'ideal' );
        }
		parent::display();
	}
}
?>