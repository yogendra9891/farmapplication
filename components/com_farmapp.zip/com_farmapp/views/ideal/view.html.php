<?php
/**
 * Joomla! 1.5 component Test Component
 *
 * @version $Id: view.html.php 2011-05-20 00:03:27 svn $
 * @author Gajendra Kumar Jain
 * @package Joomla
 * @subpackage Test Component
 * @license GNU/GPL
 *
 * 
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Test Component component
 */
class TestcomponentViewTestcomponent extends JView {
	function display($tpl = null) {
        parent::display($tpl);
    }
}
?>